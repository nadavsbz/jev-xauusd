# PREREG t256 — new-angle web scan (broker PAMM/social monitors, crypto copy leaderboards, prop leaderboards, 2023-2026 quant papers) + OwnGold v2 idea list

Written: 2026-11-15 ~10:05 Asia/Jerusalem (IST, UTC+2). Trigger: Nadav t260u ("keep scanning the web for bots/ideas").

**Hashed before any data collection for this round.** Prior RESULTS t188–t255 are frozen prior knowledge / closed list.

## Rules
Read-only public pages and unauthenticated public JSON only. No follow / copy / subscribe / buy / invest / sign-up / login (Nadav declined RoboForex sign-up; no other sign-ups). No credentials, account numbers beyond public listing IDs, or IPs printed. Frugal. Benzaquen: append-only to grok_inbox.md + grok_data\t256_*; never touch terminals, run_queue/run_tester, accounts.json, C:\MT5_JEV_DEMO.

## Not repeated (closed sources / families / ideas)
Sources exhausted: MQL5 signals (t232/t241), CopyFX full (t253), Darwinex Zero, ZuluTrade, FXBlue, FXStat, DupliTrade, cTrader, Myfxbook top lists, SignalStart, forum journals t237 (FF/BabyPips/forex-station already passed once; only NEW threads revisited).
Closed families: Gold Reaper/Limitless/Profalgo, Happy*, Kenni, Solnce/QuantumStar, TP TRADER, SARUJA, VolantFX, Lucky Cat/Jian Tu, PUMPING SQUAD, Kuropatkin/Diamondhill, TycheCerf (monitor), plus t237 closed list.
Ideas already tested: RSI2 indices, noise-zone on other indices, overnight premium, turn-of-month, ORB/NR7/impulse-pullback M15 gold, carry, FX value, CS momentum, Halloween, FOMC, TSMOM, W-shape, weekly crypto momentum, gold/silver ratio.

## Sources this round (frozen)
A. Broker PAMM/MAM/social public ratings: Alpari PAMM, Tickmill social, FxPro, Exness Social Trading (strategy JSON if public), IC Social, Pepperstone, Vantage copy, PU Prime copy, FBS/Octa copy, Admirals; Amarkets/Forex4you-type PAMM monitors (Russian PAMM monitors e.g. investflow/pammwiki if live).
B. Crypto copy leaderboards with long histories: Bybit copy (public leaderboard API), Binance copy (public), OKX/Bitget public lead-trader lists.
C. Prop-firm public leaderboards (FTMO etc.) — expected short horizons; recorded only.
D. Reddit r/algotrading / r/Forex posts with verified myfxbook/fxblue links (2024-2026).
E. Quant papers SSRN/arXiv/journals 2023-2026 on H1–D1 gold/indices/crypto/commodities with out-of-sample or post-publication evidence → OwnGold v2 idea list.

## Gate (unchanged from t253/t237)
1 Age ≥18 months (start ≤ 2025-05-15). 2 Honest TWR monthly ≥3.0% (standing 3.5%), months=(asof−start)/30.4375, as-of 2026-11-15. 3 Max DD ≤25% (stricter of curve / platform max DD / floating). 4 Top-10 days <50% of log-TWR (pending if no daily series). 5 No sibling DD >40%. 6 Replicability: net/trade ≥5× RF round trip (gold ≥10bp; FX majors ≥4–5 pips; crypto ≥5× RF crypto CFD spread+commission), median hold ≥5 min, hard SL, no latency edge; +1 pip/side stress. 7 Closed-family dedup. 8 Grid/stacking/leverage-up flags. 9 BD crash days (26 dates as t253): flag ≤−10%, fail ≤−25%.
Platform headline numbers without curves are tagged OBSERVED and can at most make a near-miss/candidate, not a passer.

## OwnGold v2 idea criteria (frozen)
Entirely different from v1 (not M15 gold breakout/pullback); H1/H4/D1 or other asset; published with out-of-sample/post-publication evidence; tradable as RoboForex ECN CFD (gold, indices, oil, FX, crypto CFDs); low overnight count preferred (swap −6% to −8.6%/yr); not in the tested-ideas list. Rank by evidence quality × fit × cost robustness.

## Outputs
RESULTS_t256_scan.md (+ .sha256), results_t256/raw, results_t256/analysis; Hebrew grok_inbox entry for Claude; copy to Benzaquen grok_data\t256_scan\.
