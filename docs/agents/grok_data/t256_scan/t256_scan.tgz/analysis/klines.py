import json,subprocess,time,sys
def pull(sym,start_ms,fn):
    out=[];s=start_ms
    while True:
        r=json.loads(subprocess.run(['curl','-s','-m','20',f'https://data-api.binance.vision/api/v3/klines?symbol={sym}&interval=1h&startTime={s}&limit=1000'],capture_output=True,text=True).stdout)
        if not isinstance(r,list) or not r: break
        out+=[[x[0],float(x[1]),float(x[4])] for x in r]
        s=r[-1][0]+3600000
        if len(r)<1000: break
        time.sleep(0.15)
    json.dump(out,open(fn,'w')); print(sym,len(out))
pull('BTCUSDT',1577836800000,'klines/BTCUSDT_1h.json')
pull('PAXGUSDT',1577836800000,'klines/PAXGUSDT_1h.json')
