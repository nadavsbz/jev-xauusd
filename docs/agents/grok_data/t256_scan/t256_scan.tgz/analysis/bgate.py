import json,glob,datetime,statistics as S,math
BD="2026-04-21 2026-04-23 2026-04-30 2026-05-01 2026-05-04 2026-05-14 2026-05-25 2026-05-27 2026-05-29 2026-06-02 2026-06-05 2026-06-18 2026-06-24 2026-06-30 2026-07-01 2026-07-30 2026-08-05 2026-08-06 2026-08-10 2026-08-11 2026-08-21 2026-08-27 2026-09-14 2026-09-16 2026-09-22 2026-10-12".split()
res=[]
for f in glob.glob('raw/binance/deep/*.json'):
    p=f.split('/')[-1][:-5]; d=json.load(open(f)); det=json.load(open(f'raw/binance/detail/{p}.json'))['data']
    ch=sorted(d['chart'],key=lambda x:x['dateTime'])
    eq=[1+x['value']/100 for x in ch]; dates=[datetime.datetime.utcfromtimestamp(x['dateTime']/1000).date().isoformat() for x in ch]
    rets=[eq[i]/eq[i-1]-1 for i in range(1,len(eq))]
    pk=eq[0];dd=0
    for e in eq: pk=max(pk,e); dd=min(dd,e/pk-1)
    tot=math.log(eq[-1]/eq[0]) if eq[-1]>0 else float('nan')
    top=sorted(rets,reverse=True)[:10]; share=sum(math.log(1+r) for r in top)/tot if tot>0 else float('nan')
    m=len(eq)/30.4375; mon=(eq[-1]/eq[0])**(1/m)-1
    bdd={dates[i]:rets[i-1] for i in range(1,len(dates)) if dates[i] in BD}
    pos=d['pos']; holds=[(x['closed']-x['opened'])/60000 for x in pos if x.get('closed')]
    bps=[x['closingPnl']/(x['avgCost']*x['closedVolume'])*1e4 for x in pos if x.get('closedVolume') and x['avgCost']]
    syms={}
    for x in pos: syms[x['symbol']]=syms.get(x['symbol'],0)+1
    lev=sorted(set(x['leverage'] for x in pos))
    res.append(dict(id=p,name=det['nickname'],start=datetime.datetime.utcfromtimestamp(det['startTime']/1000).date().isoformat(),aum=round(float(det['aumAmount'])),roi365=round(d['perf']['roi'],1),mdd365_platform=d['perf']['mdd'],orders365=d['perf']['totalOrder'],curve_dd=round(dd*100,1),mon12=round(mon*100,2),top10share=round(share*100,1),worstBD=round(min(bdd.values())*100,2) if bdd else None,npos=len(pos),pos_total=d['pos_total'],med_hold_min=round(S.median(holds)) if holds else None,med_bp_notional=round(S.median(bps),1) if bps else None,mean_bp=round(S.mean(bps),1) if bps else None,syms=dict(sorted(syms.items(),key=lambda kv:-kv[1])[:4]),lev=lev[:5],tags=det.get('tag'),api=('API_KEY_TRADE' in (det.get('tag') or []))))
res.sort(key=lambda r:-r['mon12'])
json.dump(res,open('analysis/binance_gate.json','w'),indent=1)
for r in res: print(r)
