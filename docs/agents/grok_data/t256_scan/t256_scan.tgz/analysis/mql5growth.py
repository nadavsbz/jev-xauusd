import re,sys,datetime,math,json
BD=set("2026-04-21 2026-04-23 2026-04-30 2026-05-01 2026-05-04 2026-05-14 2026-05-25 2026-05-27 2026-05-29 2026-06-02 2026-06-05 2026-06-18 2026-06-24 2026-06-30 2026-07-01 2026-07-30 2026-08-05 2026-08-06 2026-08-10 2026-08-11 2026-08-21 2026-08-27 2026-09-14 2026-09-16 2026-09-22 2026-10-12".split())
out={}
for id in sys.argv[1:]:
    t=open(f'raw/mql5/{id}.html',errors='ignore').read()
    arrs=re.findall(r'\[\s*(1[67]\d{8}\s*,[^\]]*)\]',t)
    # growth array: pairs ts,val
    g=None
    for a in arrs:
        v=[float(x) for x in a.split(',') if x.strip()]
        if len(v)%2==0 and len(v)>10 and all(v[i]>1.6e9 for i in range(0,len(v),2)):
            g=v;break
    pts=[(datetime.datetime.utcfromtimestamp(g[i]).date(),g[i+1]) for i in range(0,len(g),2)]
    eq=[1+p[1]/100 for p in pts]
    pk=eq[0];dd=0
    for e in eq: pk=max(pk,e);dd=min(dd,e/pk-1)
    rets=[eq[i]/eq[i-1]-1 for i in range(1,len(eq))]
    tot=math.log(eq[-1]/eq[0]); top=sorted(rets,reverse=True)[:10]
    share=sum(math.log(1+r) for r in top)/tot
    asof=datetime.date(2026,11,15); months=(asof-pts[0][0]).days/30.4375
    mon=(eq[-1]/eq[0])**(1/months)-1
    gaps=[(pts[i][0]-pts[i-1][0]).days for i in range(1,len(pts))]
    resid=math.exp(tot-sum(math.log(1+r) for r in top))**(1/months)-1
    out[id]=dict(start=str(pts[0][0]),end=str(pts[-1][0]),n=len(pts),median_gap_days=sorted(gaps)[len(gaps)//2],growth_end=pts[-1][1],months=round(months,1),monthly=round(mon*100,2),curve_dd=round(dd*100,1),top10_share=round(share*100,1),resid_monthly=round(resid*100,2),worst_period=round(min(rets)*100,2))
    print(id,out[id])
json.dump(out,open('analysis/mql5_growth.json','w'),indent=1)
