import json,datetime,math,statistics as S
k=json.load(open('raw/klines/BTCUSDT_1h.json'))
day={}
for t,o,c in k:
    d=datetime.datetime.utcfromtimestamp(t/1000).date()
    hi,lo,_=day.get(d,(c,c,c)); day[d]=(max(hi,c,o),min(lo,c,o),c)
ds=sorted(day); H=[day[d][0] for d in ds]; L=[day[d][1] for d in ds]; C=[day[d][2] for d in ds]
Ns=[5,10,20,30,60,90,150,250,360]
state={n:0 for n in Ns}; pos=[]
for i in range(len(ds)):
    for n in Ns:
        if i<n: continue
        if C[i]>=max(H[i-n:i]): state[n]=1
        elif C[i]<=min(L[i-n//2 if n>=2 else i-1:i]): state[n]=0
    pos.append(sum(state.values())/len(Ns))
rets=[C[i]/C[i-1]-1 for i in range(1,len(C))]
# vol target 25% using 30d realized vol, cap lev 1
out=[]
for i in range(31,len(C)):
    vol=S.pstdev(rets[i-31:i-1])*math.sqrt(365)
    w=min(1.0,0.25/vol if vol>0 else 1)*pos[i-1]
    out.append((ds[i],w*rets[i-1+0] if False else w*(C[i]/C[i-1]-1),w))
def st(a,b,lab):
    r=[x for x in out if a<=x[0]<b]; eq=1;pk=1;dd=0
    for _,x,_ in r: eq*=1+x;pk=max(pk,eq);dd=min(dd,eq/pk-1)
    yrs=len(r)/365; ex=sum(1 for _,_,w in r if w>0)/len(r)
    print(f"{lab:22s} CAGR={(eq**(1/yrs)-1)*100:6.1f}% DD={dd*100:6.1f}% exposure_days={ex:.2f} avg_w={S.mean(w for *_,w in r):.2f}")
D=datetime.date
st(D(2020,2,1),D(2025,4,1),'2020-25/03 (paper IS)')
st(D(2025,4,1),D(2027,1,1),'2025/04-26/11 post-pub')
for y in range(2021,2027): st(D(y,1,1),D(y+1,1,1),str(y))
bh=C[ds.index(D(2025,4,1))]; print('BTC B&H post-pub',round((C[-1]/bh-1)*100,1),'%')
