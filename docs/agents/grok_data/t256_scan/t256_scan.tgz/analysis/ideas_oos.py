import json,datetime,math,statistics as S
from collections import defaultdict
def load(f):
    d=json.load(open(f)); return {x[0]//1000:(x[1],x[2]) for x in d}
def stats(tr,label):
    if not tr: return
    r=[x[1] for x in tr]; eq=1;pk=1;dd=0
    for x in r: eq*=1+x; pk=max(pk,eq); dd=min(dd,eq/pk-1)
    yrs=(tr[-1][0]-tr[0][0]).days/365.25 or 1
    m=S.mean(r); sd=S.pstdev(r)
    print(f"{label:38s} n={len(r):5d} mean={m*1e4:6.1f}bp med={S.median(r)*1e4:6.1f} hit={sum(x>0 for x in r)/len(r):.2f} CAGR={(eq**(1/yrs)-1)*100:6.1f}% DD={dd*100:6.1f}% tSR={m/sd*math.sqrt(len(r)/yrs) if sd else 0:.2f}")
def session(k,h0,h1,days=None,filt=None):
    # return list of (date, ret) open at h0 close at h1-1 bar close
    out=[]
    ts=sorted(k); first=datetime.datetime.utcfromtimestamp(ts[0]).date(); last=datetime.datetime.utcfromtimestamp(ts[-1]).date()
    d=first
    while d<=last:
        t0=int(datetime.datetime(d.year,d.month,d.day,tzinfo=datetime.timezone.utc).timestamp())
        a=t0+h0*3600; b=t0+(h1-1)*3600
        if a in k and b in k and (days is None or d.weekday() in days):
            if filt is None or filt(k,t0):
                out.append((d,k[b][1]/k[a][0]-1))
        d+=datetime.timedelta(days=1)
    return out
def split(tr,cuts,label):
    for (a,b,n) in cuts:
        stats([x for x in tr if a<=x[0]<b],f"{label} {n}")
D=datetime.date
btc=load('raw/klines/BTCUSDT_1h.json')
print("=== BTC long 21-23 UTC (Quantpedia Feb-2022, ext Sep-2023)")
tr=session(btc,21,23)
split(tr,[(D(2020,1,1),D(2022,2,1),'in-sample 2020-22/01'),(D(2022,2,1),D(2023,7,1),'post-pub1 2022/02-23/06'),(D(2023,7,1),D(2027,1,1),'OOS 2023/07-26/11')],'BTC21-23')
for y in range(2020,2027): stats([x for x in tr if x[0].year==y],f"  year {y}")
tr2=session(btc,21,23,days={3,4})
split(tr2,[(D(2023,7,1),D(2027,1,1),'OOS Thu+Fri')],'BTC21-23')
print("=== PAXG (gold proxy) sessions")
pax=load('raw/klines/PAXGUSDT_1h.json')
wk={0,1,2,3,4}
for (h0,h1,n) in [(0,8,'Asia 00-08'),(8,14,'Europe 08-14'),(14,21,'US 14-21'),(21,24,'late 21-24')]:
    t=session(pax,h0,h1,days=wk)
    split(t,[(D(2020,1,1),D(2024,7,22),'2020-24/07 (post-CBS2019, pre-Wei)'),(D(2024,7,22),D(2027,1,1),'2024/07-26/11 (Wei sample+)')],'PAXG '+n)
asia=session(pax,0,8,days=wk)
for y in range(2020,2027): stats([x for x in asia if x[0].year==y],f"  Asia year {y}")
# filter: prior US session (14-21 prev day) up
def prevus_up(k,t0):
    a=t0-24*3600+14*3600; b=t0-24*3600+20*3600
    return a in k and b in k and k[b][1]>k[a][0]
def prevus_dn(k,t0):
    a=t0-24*3600+14*3600; b=t0-24*3600+20*3600
    return a in k and b in k and k[b][1]<k[a][0]
for f,n in [(prevus_up,'prevUS up'),(prevus_dn,'prevUS down')]:
    t=session(pax,0,8,days=wk,filt=f)
    split(t,[(D(2020,1,1),D(2024,7,22),'pre'),(D(2024,7,22),D(2027,1,1),'post')],'PAXG Asia '+n)
